Ubuntu 16.04 64bit

New machine: sudo bash begin.sh 

If already installed JDK,Maven3,Docker : sudo bash deploy.sh